# -*- coding: utf-8 -*-
"""
Created on Fri Oct  1 11:04:36 2021

@author: Raúl Aguilar -@defalcovgl-
"""

a = 4
a += 2
print(a)
a -= 3
print(a)
a *= 3
print(a)
a /= 2
print(a)
a %= 4
print(a)
a == 0
print(a)
a //= 2
print(a)

"""
b += 2  asigna el valor de como a b + 2

b -= 3 asigna el valor de b como b - 3

b *= 3 asigna el valor de b como b * 3

b /= 2 asigna el valor de b como b / 3

b %= 4 asigna el valor de b como el modulo de b / 4

b == 0 pregunta si el valor de b es igual a 0 pero sin cambiar el valor de b

b //= 2 asigna el valor de b como el valor entero del cociente de la division por 2

"""
