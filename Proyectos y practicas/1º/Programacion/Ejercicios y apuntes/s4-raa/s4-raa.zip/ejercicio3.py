# -*- coding: utf-8 -*-
"""
Created on Fri Oct  1 11:18:39 2021

@author: Raúl Aguilar -@defalcovgl-
"""

a = 3
b = 8
c = 3.0
r = a == 0  # Es un valor booleano
s = a != 0  # Es un valor booleano
t = a <= b  # Es un valor booleano
u = b >= a  # Es un valor booleano
v = b > a  # Es un valor booleano
w = b < a  # Es un valor booleano
x = c == 3.0  # Es un valor booleano
print("r:", r)
print("s:", s)
print("t:", t)
print("u:", u)
print("v:", v)
print("w:", w)
print("x:", x)

"""
el resultado es una serie de valores verdaderos y falsos que surgen de 
preguntar por los valores de a, b y c 
"""
