# -*- coding: utf-8 -*-
"""
Created on Thu Sep 23 14:13:02 2021

@author: Raúl Aguilar -@defalcovgl-
"""

txt = "¡Hola don Pepito! \n\t\t ¡Hola don José! \n ¿Pasó usted por mi casa? \n\t\t Por su casa yo pasé. \n ¿Vio usted a mi abuela? \n\t\t A su abuela yo la vi."
print(txt)