# -*- coding: utf-8 -*-
"""
Created on Thu Sep 23 12:44:46 2021

@author: Raúl Aguilar -@defalcovgl-
"""

Vint = 1                  # decalracion de un entero
Vfloat = 2.2              # decalracion de un decimal
Vbool = True              # decalracion de un valor logico/booleano
Vstr = "hola mundo 123@"  # decalracion de una cadena de caracteres

"""
la propiedad que permite declarar variables sin
especificar su tipo es que python es un lenguaje
dinamicamente tipdo
"""