# -*- coding: utf-8 -*-
"""
Created on Thu Sep 23 13:48:12 2021

@author: Raúl Aguilar -@defalcovgl-
"""

v1 = 1
v2 = v1

print(v2)

v1 = 395

print("v1 = ", v1, " ; ", "v2 = ", v2)


"""
el valor de la segunda no cabia ya que en el flujo del programa no es
modificada despues de que el valor 1 haya sido cambiado, por lo tanto, seguira
siendo igual al valor original de 1
"""
