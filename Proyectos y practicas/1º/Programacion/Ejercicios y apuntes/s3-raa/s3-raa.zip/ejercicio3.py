# -*- coding: utf-8 -*-
"""
Created on Thu Sep 23 13:00:47 2021

@author: Raúl Aguilar -@defalcovgl-
"""

a = 2
a = 7
a = 2.5
a = "una cadena de texto"
a = True
a = 2  # para probar que se puede cambiar desde bool a otro valor de nuevo
a = (1, 2, 4, 5, 7, 99)
a = [1, 2, 4, 5, 7, 99]

"""
Es posible cambiar el valor de una variable, estoy casi seguro puede modificar
el tipo de cualquier variable pero no es algo demasiado aconsejable
"""

# Mostrar el valor antiguo y el nuevo valor de la variable por pantalla.

a = 2
print(a)
a = "dos"
print(a)
