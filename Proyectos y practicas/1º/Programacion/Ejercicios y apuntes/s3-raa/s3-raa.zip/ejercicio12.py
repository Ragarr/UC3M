# -*- coding: utf-8 -*-
"""
Created on Fri Sep 24 23:06:13 2021

@author: Raúl Aguilar -@defalcovgl-
"""

nombre = 'Johnny Depp'
edad = 55
altura = 1.78
peso = 65.8
ojos = 'marrones'
pelo = 'castaño'
print("Hablemos de", nombre)
print("Tiene", edad, "años")
print("Mide", altura, "metros.")
print("Pesa", peso, "kilogramos.")
print("De hecho no está nada gordo.")
print("Tiene ojos", ojos, "y pelo", pelo, ".")

"""
si se reordena no hay apenas cambios en la salida,
mas alla de que no se como evitar que se ponga un espacio entre
cadena y cadena. ej: el ultimo punto lleva un espacio que no deberia
tener
"""
