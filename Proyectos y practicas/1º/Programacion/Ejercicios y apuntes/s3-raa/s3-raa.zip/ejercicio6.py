# -*- coding: utf-8 -*-
"""
Created on Thu Sep 23 13:46:18 2021

@author: Raúl Aguilar -@defalcovgl-
"""

v1, v2, v3 = "v1 es un str", 2, True

# es posible hacerlo pero puede afectar a la legibilidad
