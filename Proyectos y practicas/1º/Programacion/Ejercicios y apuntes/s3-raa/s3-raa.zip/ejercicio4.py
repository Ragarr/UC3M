# -*- coding: utf-8 -*-
"""
Created on Thu Sep 23 13:12:18 2021

@author: Raúl Aguilar -@defalcovgl-
"""

a = 1
a = "hola"
# esto es posible gracias a que python esta dinamicamente tipado
