juguetes = {
    'muñecas': 500,
    'juegos': ['Guess who?', 'Clue', 'Battleship'],
    'puzzles': ['Star Wars', 'Batman', 'Ironman']
}
juguetes["peluche"] = ["oso", "perro", "gato"]
del (juguetes['puzzles'][1])
juguetes["muñecas"]+=100